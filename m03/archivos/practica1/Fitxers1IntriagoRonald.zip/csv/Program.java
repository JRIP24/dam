public class Program {
    
    public static void main(String[] args){

        Training01 t1 = new Training01();
        t1.m1();
        t1.m2();
        t1.m3();
        t1.m4();
        t1.m5();
        t1.m6();
        t1.m7();
        t1.m8();
        t1.m9();
        t1.m10();

        Training02 t2 = new Training02();
        t2.m11(); 
        t2.m12();
        t2.m13();
        t2.m14();
        t2.m15();
        t2.m16();
        t2.m17();
        t2.m18();
        t2.m19();
        t2.m20();
        
        Training03 t3 = new Training03();
        t3.m21();
        t3.m22();
        t3.m23();
        t3.m24();
        t3.m25();
        t3.m26();
        t3.m27();
        t3.m28();
        t3.m29();
        t3.m30();

        Training04 t4 = new Training04();
        t4.m31();
        t4.m32();
        t4.m33();
        t4.m34();
        t4.m35();
        t4.m36();
        t4.m37();
        t4.m38();
        t4.m39();
        t4.m40();

        Training05 t5 = new Training05();
        t5.m41();
        t5.m42();
        t5.m43();
        t5.m44();
        t5.m45();
        t5.m46();
        t5.m47();
        t5.m48();
        t5.m49();
        t5.m50();

        Training06 t6 = new Training06();
        t6.m51();
        t6.m52();
        t6.m53();
        t6.m54();
        t6.m55();
        t6.m56();
        t6.m57();
        t6.m58();
        t6.m59();
        t6.m60();

    }
}