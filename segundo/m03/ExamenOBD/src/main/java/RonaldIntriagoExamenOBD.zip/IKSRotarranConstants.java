public interface IKSRotarranConstants {
	
	String[] LLOCS_DE_SERVEI = {"", "pont", "enginyeria", "cuina", "infermeria", "sala d'armes"};
	String[] DEPARTAMENTS = {"", "Comandament", "Armes", "Timó i navegació", "Enginyeria", "Ciència"};
	
	String pathBD = "baseDeDades/Rotarran_logistica.db4o";
	
	String pathArxiusExportacioXML = "arxiusXML/productesExportats.xml";
	String pathArxiusImportacioXML = "arxiusXML/productesImportats.xml";

}
