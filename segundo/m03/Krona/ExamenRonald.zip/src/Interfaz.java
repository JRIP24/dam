
public interface Interfaz {
	
	String[] TIPUS_WAYPOINT = {"planeta", "lluna", "asteroide", "cometa", "meteor", "planetoide", "punt en l'espai"};
}
