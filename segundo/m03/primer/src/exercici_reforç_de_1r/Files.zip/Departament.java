package exercici_reforç_de_1r;

public class Departament {
	
	private int ID;
	private String nom;
	private String descripcio;
	
	public Departament(int id, String n, String desc) {
		
		this.ID = id;
		this.nom = n;
		this.descripcio = desc;
	}
}
