package exercici_reforç_de_1r;

public interface IKSRotarranConstants {
	
	String[] LLOCS_DE_SERVEI = {"", "pont", "enginyeria", "cuina", "infermeria", "sala d'armes"};	 
	String[] DEPARTAMENTS = {"", "comandament" , "armes", "timó i navegació", "enginyeria", "ciència"};
	

}